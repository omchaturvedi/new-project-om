package com.example.Train_Booking_System;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TrainBookingSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
